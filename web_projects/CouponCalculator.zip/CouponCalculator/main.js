function CalculateDiscount() {
    "use strict";
    
    var cost = document.getElementById("price").value;
    var discount = "." + document.getElementById("percent").value;
    
    var sale_price = Math.round(parseFloat(discount) * cost);
    alert("You saved $" + sale_price + "!");
}
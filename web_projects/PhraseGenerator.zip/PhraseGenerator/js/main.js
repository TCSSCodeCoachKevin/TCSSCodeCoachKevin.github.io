// JavaScript Document

function getPhrase() {
	
	"use strict";
	var quotes = ["Gotta Catch e'm All!", "Ruh-Roh", "Do or do not, there is no try", "Life always finds a way", "Well, anything sounds weird if you say it a hundred times"];
	var randomIndex = (Math.floor(Math.random() * quotes.length));
	var randomQuote = quotes[randomIndex];
	
	document.getElementById("phrase").innerHTML = randomQuote;
	
}
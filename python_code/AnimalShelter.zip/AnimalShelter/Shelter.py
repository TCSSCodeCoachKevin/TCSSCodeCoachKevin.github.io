class AnimalShelter:
  def __init__(self, animals):
    self.animals = animals
    
  #Display All Animals in Shelter
  def DisplayAnimals(self):
    for animal in self.animals:
      print(animal.species + "(" + animal.breed +  ")" + " is " + str(animal.age) + " years old.")
      
  #Adopt Animal
  def AdoptAnimal(self, animal):
    #Remove Animal From Shelter
    for animals in self.animals:
      #Found Animal
      if animals.species == animal:
        self.animals.remove(animals)
        #Inform Adoptee of Animal Selected
        print("You adopted " + animals.species)
        break
    
  #Find Animals in Shelter based on age
  def FindOldest(self):
    for old_animal in range(self.animals):
      #First Animal Age
      ani = self.animals[old_animal]
      age = ani.age
      #Next Animal Age
      if age > self.animals[old_animal + 1].age:
        age = self.animals[old_animal + 1].age
        continue
      else:
        continue
    
  def FindYoungest(self):
    pass
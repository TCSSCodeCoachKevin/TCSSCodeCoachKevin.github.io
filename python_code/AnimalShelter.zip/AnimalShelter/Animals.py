class animals:
  def __init__(self, species, age, breed):
    self.species = species
    self.age = age
    self.breed = breed
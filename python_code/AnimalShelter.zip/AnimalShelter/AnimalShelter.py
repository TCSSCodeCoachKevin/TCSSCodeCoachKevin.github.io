import Shelter
import Animals

#Create Some Animals
a_1 = Animals.animals("elephant", 50, "African")
a_2 = Animals.animals("tiger", 12, "Siberian")
a_3 = Animals.animals("lion", 6, "East African")
a_4 = Animals.animals("rhinoceros", 43, "Javan")

#Store Animal Objects in List
shelter_animals = [a_1, a_2, a_3, a_4]

#Create Animal Shelter
zoo = Shelter.AnimalShelter(shelter_animals)

#Open Shelter
print("Welcome to this Crazy Zoo Shelter\n")
zoo.DisplayAnimals()

#Request Animal From Customer
customer_animal = input("\nWhich animal would you like to adopt?").lower()
if "oldest" in customer_animal:
  zoo.FindOldest()
elif "youngest" in customer_animal:
  pass
  #FindYoungest
else:
  #Search for their requested animal
  for a in zoo.animals:
    #Check if customer requested valid animal from shelter
    if customer_animal == a.species:
      zoo.AdoptAnimal(customer_animal)
      break
    
    
    
    
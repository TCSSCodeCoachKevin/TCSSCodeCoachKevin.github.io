class Movie:
  def __init__(self, name, rating, seatsLeft, ticketPrice):
    self.name = name
    self.rating = rating
    self.seatsLeft = seatsLeft
    self.ticketPrice = ticketPrice
    
  #Getter
  def GetSeatsLeft(self):
    return self.seatsLeft
  
  #Setter
  def PurchaseSeats(self, ticketsSold):
    try:
      self.seatsLeft -= ticketsSold
    except:
      print("Sorry, there are only " + str(self.seatsLeft))
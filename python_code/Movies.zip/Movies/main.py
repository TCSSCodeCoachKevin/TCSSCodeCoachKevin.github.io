import random
import Theater

#Create Movies 
movies_1 = Theater.Movie("Spider-Man", "PG-13", 26, 11.75)
movies_2 = Theater.Movie("Toy Story", "PG", 18, 13.25)
movies_3 = Theater.Movie("Star Wars", "PG-13", 30, 10.50)
movies_4 = Theater.Movie("Jurassic Park: Extended Cut", "R", 28 , 14.00)

#Create theater of movies
theater = [movies_1, movies_2, movies_3, movies_4]

theaterMoolah = 0

#Customers Arrive
for x in range(5):
  #Choose movie
  movieChoice = random.choice(theater)
  print("\nCustomer wants to see " + movieChoice.name)
  
  #Tell Customer Information
  print("There are " + str(movieChoice.GetSeatsLeft()) + " tickets available for this movie")
  
  if movieChoice.rating == "R":
    print("This movie is rated " + movieChoice.rating)
  
  #Close Transaction
  customerTickets = random.randint(1, movieChoice.GetSeatsLeft())
  movieChoice.PurchaseSeats(customerTickets)
  theaterMoolah += customerTickets * movieChoice.ticketPrice
  
#Collect Revenue 
print("Theater made $" + str(theaterMoolah))
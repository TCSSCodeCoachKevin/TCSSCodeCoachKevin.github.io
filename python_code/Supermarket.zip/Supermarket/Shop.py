class Supermarket:
  def __init__(self, products):
    self.products = products
    
  def DisplayShopItems(self):
    for x in range(len(self.products)):
      print(self.products[x].name + " $" + str(self.products[x].price))
import random
import Shop
import Products

#Create Store Items
item_1 = Products.Product("Bread", 9.99)
item_2 = Products.Product("Pickles", 3.99)
item_3 = Products.Product("Soda", 2.50)
item_4 = Products.Product("Cake", 19.99)

#Store items in market
inventory = [item_1, item_2, item_3, item_4]
store = Shop.Supermarket(inventory)

print("WELCOME TO SHOP_SHOP\n")

#Shop Store Items
store.DisplayShopItems()

revenue = 0
sales = 0
customers = random.randint(1, 10)
customerCart = []

#Customers Arrive
for cust in range(customers):
  sales += 1
  #Customer Gets Items For Cart
  customerItems = random.randint(1, len(store.products))
  #Generate Random Item From Shop
  customerCart.append(random.choice(store.products))

  print("Customer #" + str(sales))
  #Display Customer Cart
  for item in customerCart:
    print("\n" + item.name)
    revenue += (item.price)

#Shop Closes
print("TOTAL REVENUE " + str(revenue))
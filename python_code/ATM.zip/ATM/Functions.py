import BankCustomers

#Create Customers
p1 = BankCustomers.CreateCustomer("Jim", "1111", 1200)
p2 = BankCustomers.CreateCustomer("David", "0000", 400)
p3 = BankCustomers.CreateCustomer("Kelly", "1234", 647)
p4 = BankCustomers.CreateCustomer("Dan", "0907", 345)

customerList = [p1, p2, p3, p4]

def FindCustomer(pin):
  sign_in_customer = None
  for x in range (len(customerList)):
    person = customerList[x]
    if pin == person.pin:
      sign_in_customer = person
      break
    else:
      continue      
  return sign_in_customer
  
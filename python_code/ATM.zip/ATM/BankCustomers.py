class CreateCustomer:
  def __init__(self, name, pin, balance):
    self.name = name
    self.pin = pin
    self.balance = balance
    
  #setters
  def Withdraw(self, money):
    self.balance -= money
    
  def Deposit(self, money):
    self.balance += money
import Functions

customer = None
#ATM START UP
print("ATM READY")

#User must enter pin
pin_entry = input("Enter your 4 digit pin:\n")

#check length of pin
if len(pin_entry) != 4:
  print("Invalid Pin")  
else:
  customer = Functions.FindCustomer(pin_entry)
  print("Welcome " + customer.name)
  print("You have a current balance of $" + str(customer.balance))
  
  menu_option = None
  while menu_option != "3":
    #open menu
    menu_option = input("1. Deposit\n2. Withdraw\n3. Log Out\n\n")
    
    if menu_option == "1":
      moolah = int(input("How much would you like to deposit?\n"))
      customer.Deposit(moolah)
      print("You now have " + str(customer.balance))
    elif menu_option == "2":
      #check balance
      moolah = int(input("How much would you like to withdraw?\n"))
      if moolah <= customer.balance:
        customer.Withdraw(moolah)
        print("Balance: " + str(customer.balance))
      else:
        print("Not enough! Balance: " + str(customer.balance))
    elif menu_option == "3":
      print("Thank You for using this ATM of awesome-ness")
      exit()
    else:
      print("Invalid Option")